package com.pagoda.account.migrate.exception;

import com.pagoda.account.common.exception.ExampleException;

/**
 * @author Lixh
 * @Date: 2018/9/6 14:40
 * @Description:
 */
public class MigrateException extends ExampleException {
}
