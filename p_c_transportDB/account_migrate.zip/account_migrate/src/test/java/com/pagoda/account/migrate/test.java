package com.pagoda.account.migrate;




import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class test {

    public static void main(String[] args) throws ParseException {

        long l = Math.addExact(1L, 2L);
        System.out.println(l);

    }

}
